# Rank 04 · Cub3D

An educational ray-casting engine that parses `.cub` files, validates maps, casts DDA rays, draws textured wall columns, and handles movement/collision.

The code here intentionally excludes the third-party MiniLibX sources and compiled assets. Install the platform-appropriate MiniLibX dependency, then use the included Makefile and maps:

```bash
make
./cub3D maps/test.cub
```

Test malformed maps before testing rendering. The [animated lesson](../../../lessons/index.html#cub3d) explains parser → DDA → renderer → input flow and fish-eye/collision mistakes.
