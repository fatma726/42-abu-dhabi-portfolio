/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   save_bmp.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/20 08:00:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/20 08:00:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"

static void	write_int(int fd, int value)
{
	write(fd, &value, 4);
}

static void	write_header(int fd, t_game *game, int padding)
{
	int	file_size;
	int	header_size;
	int	info_size;
	int	w;
	int	h;

	w = game->width;
	h = game->height;
	header_size = 14;
	info_size = 40;
	file_size = header_size + info_size + (w * 3 + padding) * h;
	write(fd, "BM", 2);
	write_int(fd, file_size);
	write_int(fd, 0);
	write_int(fd, header_size + info_size);
	write_int(fd, info_size);
	write_int(fd, w);
	write_int(fd, -h);
	write(fd, "\01\00\030\00\00\00\00\00", 8);
	write_int(fd, (w * 3 + padding) * h);
	write_int(fd, 0);
	write_int(fd, 0);
	write_int(fd, 0);
	write_int(fd, 0);
}

static void	write_pixels(int fd, t_game *game, int padding)
{
	int				x;
	int				y;
	int				color;
	unsigned char	pixel[3];
	char			pad[3];

	ft_memset(pad, 0, 3);
	y = 0;
	while (y < game->height)
	{
		x = 0;
		while (x < game->width)
		{
			color = *(int *)(game->img.addr + (y * game->img.line_len
						+ x * (game->img.bpp / 8)));
			pixel[0] = color & 0xFF;
			pixel[1] = (color >> 8) & 0xFF;
			pixel[2] = (color >> 16) & 0xFF;
			write(fd, pixel, 3);
			x++;
		}
		write(fd, pad, padding);
		y++;
	}
}

void	save_bmp_image(t_game *game)
{
	int	fd;
	int	padding;

	fd = open("save.bmp", O_WRONLY | O_CREAT | O_TRUNC, 0644);
	if (fd < 0)
		error_exit(game, "Error creating BMP file");
	padding = (4 - (game->width * 3) % 4) % 4;
	write_header(fd, game, padding);
	write_pixels(fd, game, padding);
	close(fd);
	exit_game(game);
}
