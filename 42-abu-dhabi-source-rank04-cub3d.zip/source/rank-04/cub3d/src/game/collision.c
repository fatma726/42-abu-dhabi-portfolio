/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   collision.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/11 15:03:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/11 15:03:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"
#include "../../minilibx/mlx.h"

int	is_wall(t_game *game, double x, double y)
{
	int	map_x;
	int	map_y;

	map_x = (int)x;
	map_y = (int)y;
	if (map_y < 0 || !game->map[map_y])
		return (1);
	if (map_x < 0 || game->map[map_y][map_x] == '\0')
		return (1);
	if (game->map[map_y][map_x] == ' ' || game->map[map_y][map_x] == '\n')
		return (1);
	return (game->map[map_y][map_x] == '1');
}
