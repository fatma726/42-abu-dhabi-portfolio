/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cleanup.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/20 08:30:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/20 08:30:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"
#include "../../minilibx/mlx.h"

static void	free_resources(t_game *game)
{
	if (game->tex_path.north)
		free(game->tex_path.north);
	if (game->tex_path.south)
		free(game->tex_path.south);
	if (game->tex_path.west)
		free(game->tex_path.west);
	if (game->tex_path.east)
		free(game->tex_path.east);
	if (game->tex_path.sprite)
		free(game->tex_path.sprite);
}

static void	free_game_resources(t_game *game)
{
	int	i;

	if (game->zbuf)
		free(game->zbuf);
	if (game->sprites)
		free(game->sprites);
	if (game->map)
		free_map(game->map);
	free_resources(game);
	if (game->mlx)
	{
		i = -1;
		while (++i < 4)
			if (game->textures[i].img)
				mlx_destroy_image(game->mlx, game->textures[i].img);
		i = -1;
		while (++i < SPRITE_FRAMES)
			if (game->sprite_tex[i].img)
				mlx_destroy_image(game->mlx, game->sprite_tex[i].img);
		if (game->splash.img)
			mlx_destroy_image(game->mlx, game->splash.img);
		if (game->img.img)
			mlx_destroy_image(game->mlx, game->img.img);
	}
}

void	exit_game_error(t_game *game, char *str)
{
	free_game_resources(game);
	if (game->win)
		mlx_destroy_window(game->mlx, game->win);
	write(2, "Error\n", 6);
	write(2, str, ft_strlen(str));
	write(2, "\n", 1);
	exit(1);
}

int	exit_game(t_game *game)
{
	free_game_resources(game);
	if (game->win)
		mlx_destroy_window(game->mlx, game->win);
	exit(0);
	return (0);
}
