/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_game.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/11 15:00:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/11 15:00:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"
#include "../../minilibx/mlx.h"

void	init_game(t_game *game)
{
	game->mlx = mlx_init();
	if (!game->mlx)
		error_exit("mlx init failed");
	game->win = mlx_new_window(game->mlx, W, H, "cub3D");
	if (!game->win)
		error_exit("window init failed");
	game->img.img = mlx_new_image(game->mlx, W, H);
	if (!game->img.img)
		error_exit("image init failed");
	game->img.addr = mlx_get_data_addr(game->img.img, &game->img.bpp,
			&game->img.line_len, &game->img.endian);
	load_texture(game, &game->textures[TEX_N], game->tex_path.north);
	load_texture(game, &game->textures[TEX_S], game->tex_path.south);
	load_texture(game, &game->textures[TEX_W], game->tex_path.west);
	load_texture(game, &game->textures[TEX_E], game->tex_path.east);
	game->anim_frame = 0;
	load_texture(game, &game->sprite_tex[0], "textures/evidence0.xpm");
	load_texture(game, &game->sprite_tex[1], "textures/evidence1.xpm");
	game->showing_splash = 1;
	load_png_texture(game, &game->splash, "textures/start_screen.png");
}
