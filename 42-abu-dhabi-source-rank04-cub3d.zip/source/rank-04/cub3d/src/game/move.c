/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   move.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/11 14:57:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/11 14:57:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"
#include "../../minilibx/mlx.h"
#include <math.h>

void	check_sprite_collection(t_game *game)
{
	int		i;
	double	dist;

	i = 0;
	while (i < game->sprite_count)
	{
		if (!game->sprites[i].collected)
		{
			dist = (game->player.pos_x - game->sprites[i].x)
				* (game->player.pos_x - game->sprites[i].x)
				+ (game->player.pos_y - game->sprites[i].y)
				* (game->player.pos_y - game->sprites[i].y);
			if (dist < 0.25)
				game->sprites[i].collected = 1;
		}
		i++;
	}
}

void	move_forward_backward(t_game *game, double speed, int keycode)
{
	double	new_x;
	double	new_y;

	new_x = game->player.pos_x;
	new_y = game->player.pos_y;
	if (keycode == 13)
	{
		new_x += game->player.dir_x * speed;
		new_y += game->player.dir_y * speed;
	}
	else if (keycode == 1)
	{
		new_x -= game->player.dir_x * speed;
		new_y -= game->player.dir_y * speed;
	}
	if (!is_wall(game, new_x, game->player.pos_y))
		game->player.pos_x = new_x;
	if (!is_wall(game, game->player.pos_x, new_y))
		game->player.pos_y = new_y;
	check_sprite_collection(game);
}

static void	rotate_direction(t_game *game, double rot_speed, int left)
{
	double	old_dir_x;
	double	old_plane_x;
	double	angle;

	old_dir_x = game->player.dir_x;
	old_plane_x = game->player.plane_x;
	if (left)
		angle = -rot_speed;
	else
		angle = rot_speed;
	game->player.dir_x = game->player.dir_x * cos(angle)
		- game->player.dir_y * sin(angle);
	game->player.dir_y = old_dir_x * sin(angle)
		+ game->player.dir_y * cos(angle);
	game->player.plane_x = game->player.plane_x * cos(angle)
		- game->player.plane_y * sin(angle);
	game->player.plane_y = old_plane_x * sin(angle)
		+ game->player.plane_y * cos(angle);
}

void	rotate_player(t_game *game, double rot_speed, int keycode)
{
	if (keycode == 123)
		rotate_direction(game, rot_speed, 1);
	else if (keycode == 124)
		rotate_direction(game, rot_speed, 0);
}

void	move_strafe(t_game *game, double speed, int keycode)
{
	double	new_x;
	double	new_y;

	new_x = game->player.pos_x;
	new_y = game->player.pos_y;
	if (keycode == 2)
	{
		new_x += game->player.plane_x * speed;
		new_y += game->player.plane_y * speed;
	}
	else if (keycode == 0)
	{
		new_x -= game->player.plane_x * speed;
		new_y -= game->player.plane_y * speed;
	}
	if (!is_wall(game, new_x, game->player.pos_y))
		game->player.pos_x = new_x;
	if (!is_wall(game, game->player.pos_x, new_y))
		game->player.pos_y = new_y;
	check_sprite_collection(game);
}
