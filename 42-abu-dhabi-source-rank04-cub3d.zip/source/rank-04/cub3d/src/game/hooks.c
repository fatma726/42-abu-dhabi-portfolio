/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hooks.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/11 14:58:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/11 14:58:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"
#include "../../minilibx/mlx.h"

int	handle_keypress(int keycode, void *param)
{
	t_game	*game;

	game = (t_game *)param;
	if (game->showing_splash)
	{
		if (keycode == 53)
			exit(0);
		game->showing_splash = 0;
		return (0);
	}
	if (keycode == 13)
		game->keys.w = 1;
	else if (keycode == 1)
		game->keys.s = 1;
	else if (keycode == 0)
		game->keys.a = 1;
	else if (keycode == 2)
		game->keys.d = 1;
	else if (keycode == 123)
		game->keys.left = 1;
	else if (keycode == 124)
		game->keys.right = 1;
	else if (keycode == 53)
		exit(0);
	return (0);
}

int	handle_keyrelease(int keycode, void *param)
{
	t_game	*game;

	game = (t_game *)param;
	if (keycode == 13)
		game->keys.w = 0;
	else if (keycode == 1)
		game->keys.s = 0;
	else if (keycode == 0)
		game->keys.a = 0;
	else if (keycode == 2)
		game->keys.d = 0;
	else if (keycode == 123)
		game->keys.left = 0;
	else if (keycode == 124)
		game->keys.right = 0;
	return (0);
}

static void	handle_movement(t_game *game, double speed, double rot)
{
	if (game->keys.w)
		move_forward_backward(game, speed, 13);
	if (game->keys.s)
		move_forward_backward(game, speed, 1);
	if (game->keys.a)
		move_strafe(game, speed, 0);
	if (game->keys.d)
		move_strafe(game, speed, 2);
	if (game->keys.left)
		rotate_player(game, rot, 123);
	if (game->keys.right)
		rotate_player(game, rot, 124);
}

int	game_loop(void *param)
{
	t_game		*game;
	double		speed;
	double		rot;
	static int	frame = 0;

	game = (t_game *)param;
	if (game->showing_splash)
	{
		raycasting(game);
		return (0);
	}
	speed = 0.05;
	rot = 0.04;
	handle_movement(game, speed, rot);
	frame = (frame + 1) % 6;
	if (frame == 0)
		game->anim_frame = (game->anim_frame + 1) % SPRITE_FRAMES;
	raycasting(game);
	return (0);
}
