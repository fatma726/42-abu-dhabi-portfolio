/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   overlays.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/20 08:40:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/20 08:40:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"
#include "../../minilibx/mlx.h"

void	render_splash(t_game *game)
{
	mlx_put_image_to_window(game->mlx, game->win,
		(t_mlx_img_data){game->splash.img, (t_mlx_point){0, 0}});
	mlx_string_put(game->mlx, game->win,
		(t_mlx_string){(t_mlx_point){game->width / 2 - 120, game->height - 50},
		0xFFFFFF, "PRESS ANY KEY TO START"});
}

void	check_mission_complete(t_game *game)
{
	int	i;
	int	all_collected;

	i = -1;
	all_collected = 1;
	while (++i < game->sprite_count)
	{
		if (!game->sprites[i].collected)
		{
			all_collected = 0;
			break ;
		}
	}
	if (all_collected && game->sprite_count > 0)
		mlx_string_put(game->mlx, game->win,
			(t_mlx_string){(t_mlx_point){game->width / 2 - 120,
			game->height / 2}, 0xFF0000, "VECNA'S LAIR UNLOCKED"});
	else if (game->sprite_count > 0)
		mlx_string_put(game->mlx, game->win,
			(t_mlx_string){(t_mlx_point){game->width / 2 - 100, 50},
			0xFF0000, "COLLECT ALL EVIDENCE"});
}
