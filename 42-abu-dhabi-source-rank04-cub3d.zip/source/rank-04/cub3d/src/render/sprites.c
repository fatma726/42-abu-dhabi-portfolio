/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sprites.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/17 18:22:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/17 18:22:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"
#include <math.h>

static void	swap_sprite(t_sprite *a, t_sprite *b)
{
	t_sprite	tmp;

	tmp = *a;
	*a = *b;
	*b = tmp;
}

static void	sort_sprites(t_game *game)
{
	int	i;
	int	j;

	i = 0;
	while (i < game->sprite_count)
	{
		j = i + 1;
		while (j < game->sprite_count)
		{
			if (game->sprites[i].dist < game->sprites[j].dist)
				swap_sprite(&game->sprites[i], &game->sprites[j]);
			j++;
		}
		i++;
	}
}

static void	calc_sprite_draw_params(t_game *game, int idx, double *p, int *d)
{
	double	inv;
	double	s[2];

	s[0] = game->sprites[idx].x - game->player.pos_x;
	s[1] = game->sprites[idx].y - game->player.pos_y;
	inv = 1.0 / (game->player.plane_x * game->player.dir_y
			- game->player.dir_x * game->player.plane_y);
	p[0] = inv * (game->player.dir_y * s[0] - game->player.dir_x * s[1]);
	p[1] = inv * (-game->player.plane_y * s[0] + game->player.plane_x * s[1]);
	d[0] = (int)((W / 2) * (1 + p[0] / p[1]));
	d[1] = (int)fabs(H / p[1]);
	d[2] = -d[1] / 2 + H / 2;
	if (d[2] < 0)
		d[2] = 0;
	d[3] = d[1] / 2 + H / 2;
	if (d[3] >= H)
		d[3] = H - 1;
	d[4] = (int)fabs(H / p[1]);
	d[5] = -d[4] / 2 + d[0];
	if (d[5] < 0)
		d[5] = 0;
	d[6] = d[4] / 2 + d[0];
	if (d[6] >= W)
		d[6] = W - 1;
	d[7] = d[0];
}

static void	draw_sprite_pixels(t_game *game, t_img *tex, int x, int *d)
{
	int	y;
	int	tex_y;
	int	color;
	int	tex_x;
	int	trans_key;

	tex_x = (int)((x - (-d[4] / 2 + d[7])) * tex->width / d[4]);
	trans_key = get_texture_color(tex, 0, 0);
	y = d[2];
	while (y < d[3])
	{
		tex_y = ((((y * 256 - H * 128 + d[1] * 128) * tex->height)
					/ d[1]) / 256);
		color = get_texture_color(tex, tex_x, tex_y);
		if (color != trans_key)
			put_pixel(&game->img, x, y, color);
		y++;
	}
}

void	render_sprites(t_game *game)
{
	int		i;
	double	p[2];
	int		d[8];
	int		x;
	t_img	*tex;

	if (game->sprite_count <= 0)
		return ;
	i = -1;
	while (++i < game->sprite_count)
		game->sprites[i].dist = (game->player.pos_x - game->sprites[i].x)
			* (game->player.pos_x - game->sprites[i].x)
			+ (game->player.pos_y - game->sprites[i].y)
			* (game->player.pos_y - game->sprites[i].y);
	sort_sprites(game);
	tex = &game->sprite_tex[game->anim_frame % SPRITE_FRAMES];
	i = -1;
	while (++i < game->sprite_count)
	{
		if (game->sprites[i].collected)
			continue ;
		calc_sprite_draw_params(game, i, p, d);
		if (p[1] <= 0)
			continue ;
		x = d[5] - 1;
		while (++x < d[6])
			if (p[1] < game->zbuf[x])
				draw_sprite_pixels(game, tex, x, d);
	}
}
