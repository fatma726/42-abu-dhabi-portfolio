/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   column.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/17 18:40:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/17 18:40:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"
#include <math.h>

static t_img	*select_texture(t_game *game, t_ray *ray)
{
	if (ray->side == 0)
	{
		if (ray->dir_x > 0)
			return (&game->textures[TEX_E]);
		else
			return (&game->textures[TEX_W]);
	}
	else
	{
		if (ray->dir_y > 0)
			return (&game->textures[TEX_S]);
		else
			return (&game->textures[TEX_N]);
	}
}

static void	calc_tex_params(t_game *game, t_ray *ray, t_img *tex, double *params)
{
	double	wall_x;
	double	step;
	double	tex_pos;

	if (ray->side == 0)
		wall_x = game->player.pos_y + ray->perp_wall_dist * ray->dir_y;
	else
		wall_x = game->player.pos_x + ray->perp_wall_dist * ray->dir_x;
	wall_x -= floor(wall_x);
	params[0] = (int)(wall_x * (double)tex->width);
	if (params[0] < 0)
		params[0] = 0;
	if (params[0] >= tex->width)
		params[0] = tex->width - 1;
	if ((ray->side == 0 && ray->dir_x > 0) || (ray->side == 1 && ray->dir_y < 0))
		params[0] = tex->width - params[0] - 1;
	step = 1.0 * tex->height / ray->line_height;
	tex_pos = (ray->draw_start - H / 2 + ray->line_height / 2) * step;
	params[1] = step;
	params[2] = tex_pos;
}

void	draw_column(t_game *game, t_ray *ray, int x)
{
	int		y;
	t_img	*tex;
	double	params[3];
	int		tex_y;
	int		color;

	ray->line_height = (int)(H / ray->perp_wall_dist);
	ray->draw_start = -ray->line_height / 2 + H / 2;
	if (ray->draw_start < 0)
		ray->draw_start = 0;
	ray->draw_end = ray->line_height / 2 + H / 2;
	if (ray->draw_end >= H)
		ray->draw_end = H - 1;
	tex = select_texture(game, ray);
	calc_tex_params(game, ray, tex, params);
	y = -1;
	while (++y < ray->draw_start)
		put_pixel(&game->img, x, y, game->ceiling.value);
	while (y <= ray->draw_end)
	{
		tex_y = (int)params[2] & (tex->height - 1);
		color = get_texture_color(tex, (int)params[0], tex_y);
		// Apply a subtle red tint: boost red, reduce green/blue
		color = (((color >> 16) & 0xFF) << 16) | 
				(((color >> 8) & 0xFF) / 2 << 8) | 
				((color & 0xFF) / 2);
		put_pixel(&game->img, x, y, color);
		params[2] += params[1];
		y++;
	}
	while (y < H)
		put_pixel(&game->img, x, y++, game->floor.value);
}
