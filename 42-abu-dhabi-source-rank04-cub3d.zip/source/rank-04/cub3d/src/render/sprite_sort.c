/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sprite_sort.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/20 09:20:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/20 09:20:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"

static void	swap_sprite(t_sprite *a, t_sprite *b)
{
	t_sprite	tmp;

	tmp = *a;
	*a = *b;
	*b = tmp;
}

void	sort_sprites(t_game *game)
{
	int	i;
	int	j;

	i = 0;
	while (i < game->sprite_count)
	{
		j = i + 1;
		while (j < game->sprite_count)
		{
			if (game->sprites[i].dist < game->sprites[j].dist)
				swap_sprite(&game->sprites[i], &game->sprites[j]);
			j++;
		}
		i++;
	}
}
