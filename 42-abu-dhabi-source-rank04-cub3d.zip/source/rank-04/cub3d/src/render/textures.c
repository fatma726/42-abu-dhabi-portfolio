/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   textures.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/11 14:55:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/11 14:55:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"
#include "../../minilibx/mlx.h"

void	load_texture(t_game *game, t_img *tex, char *path)
{
	tex->img = mlx_xpm_file_to_image(game->mlx, path, &tex->width,
			&tex->height);
	if (!tex->img)
	{
		write(2, "Error\nFailed to load texture: ", 30);
		write(2, path, ft_strlen(path));
		write(2, "\n", 1);
		exit(1);
	}
	tex->addr = mlx_get_data_addr(tex->img, &tex->bpp, &tex->line_len,
			&tex->endian);
}

void	load_png_texture(t_game *game, t_img *tex, char *path)
{
	tex->img = mlx_png_file_to_image(game->mlx, path, &tex->width,
			&tex->height);
	if (!tex->img)
	{
		write(2, "Error\nFailed to load PNG texture: ", 34);
		write(2, path, ft_strlen(path));
		write(2, "\n", 1);
		exit(1);
	}
	tex->addr = mlx_get_data_addr(tex->img, &tex->bpp, &tex->line_len,
			&tex->endian);
}

int	get_texture_color(t_img *tex, int x, int y)
{
	int	*color;

	if (x < 0)
		x = 0;
	if (x >= tex->width)
		x = tex->width - 1;
	if (y < 0)
		y = 0;
	if (y >= tex->height)
		y = tex->height - 1;
	color = (int *)(tex->addr + (y * tex->line_len + x * (tex->bpp / 8)));
	return (*color);
}
