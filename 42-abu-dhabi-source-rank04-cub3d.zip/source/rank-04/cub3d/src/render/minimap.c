/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minimap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/17 18:23:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/17 18:23:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"

static void	draw_rect(t_game *game, int x, int y, int color)
{
	int	i;
	int	j;
	int	tile;

	tile = 6;
	j = 0;
	while (j < tile - 1)
	{
		i = 0;
		while (i < tile - 1)
		{
			if (x + i >= 0 && x + i < W && y + j >= 0 && y + j < H)
				put_pixel(&game->img, x + i, y + j, color);
			i++;
		}
		j++;
	}
}

static void	draw_entities_minimap(t_game *game, int margin, int tile)
{
	int	i;

	i = 0;
	while (i < game->sprite_count)
	{
		if (!game->sprites[i].collected)
		{
			draw_rect(game, margin + (int)(game->sprites[i].x * tile) - 1,
				margin + (int)(game->sprites[i].y * tile) - 1, 0x00AAFF);
		}
		i++;
	}
	draw_rect(game, margin + (int)(game->player.pos_x * tile) - 2,
		margin + (int)(game->player.pos_y * tile) - 2, 0xFF0000);
}

void	draw_minimap(t_game *game)
{
	int	tile;
	int	margin;
	int	y;
	int	x;
	int	color;

	tile = 6;
	margin = 8;
	y = 0;
	while (game->map && game->map[y] && y < 100)
	{
		x = 0;
		while (game->map[y][x])
		{
			if (game->map[y][x] == '1')
				color = 0x220000;
			else if (game->map[y][x] == '0' || game->map[y][x] == '2')
				color = 0x111111;
			else
				color = 0x000000;
			draw_rect(game, margin + x * tile, margin + y * tile, color);
			x++;
		}
		y++;
	}
	draw_entities_minimap(game, margin, tile);
}
