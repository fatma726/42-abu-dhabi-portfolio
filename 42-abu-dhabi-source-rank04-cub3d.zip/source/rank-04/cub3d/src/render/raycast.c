/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   raycast.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/11 15:16:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/11 15:16:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"
#include "../../minilibx/mlx.h"
#include <math.h>

static void	calculate_side_dist(t_game *game, t_ray *ray)
{
	if (ray->dir_x < 0)
	{
		ray->step_x = -1;
		ray->side_dist_x = (game->player.pos_x - ray->map_x)
			* ray->delta_dist_x;
	}
	else
	{
		ray->step_x = 1;
		ray->side_dist_x = (ray->map_x + 1.0 - game->player.pos_x)
			* ray->delta_dist_x;
	}
	if (ray->dir_y < 0)
	{
		ray->step_y = -1;
		ray->side_dist_y = (game->player.pos_y - ray->map_y)
			* ray->delta_dist_y;
	}
	else
	{
		ray->step_y = 1;
		ray->side_dist_y = (ray->map_y + 1.0 - game->player.pos_y)
			* ray->delta_dist_y;
	}
}

void	calculate_step_dist(t_game *game, t_ray *ray)
{
	if (ray->dir_x == 0)
		ray->delta_dist_x = 1e30;
	else
		ray->delta_dist_x = fabs(1 / ray->dir_x);
	if (ray->dir_y == 0)
		ray->delta_dist_y = 1e30;
	else
		ray->delta_dist_y = fabs(1 / ray->dir_y);
	calculate_side_dist(game, ray);
}

void	perform_dda(t_game *game, t_ray *ray)
{
	int	hit;

	hit = 0;
	while (hit == 0)
	{
		if (ray->side_dist_x < ray->side_dist_y)
		{
			ray->side_dist_x += ray->delta_dist_x;
			ray->map_x += ray->step_x;
			ray->side = 0;
		}
		else
		{
			ray->side_dist_y += ray->delta_dist_y;
			ray->map_y += ray->step_y;
			ray->side = 1;
		}
		if (game->map[ray->map_y][ray->map_x] == '1')
			hit = 1;
	}
}

static void	check_mission_complete(t_game *game)
{
	int	i;
	int	all_collected;

	i = 0;
	all_collected = 1;
	while (i < game->sprite_count)
	{
		if (!game->sprites[i].collected)
		{
			all_collected = 0;
			break ;
		}
		i++;
	}
	if (all_collected && game->sprite_count > 0)
	{
		mlx_string_put(game->mlx, game->win,
			(t_mlx_string){(t_mlx_point){W / 2 - 120, H / 2}, 0xFF0000, "VECNA'S LAIR UNLOCKED"});
	}
	else if (game->sprite_count > 0)
	{
		mlx_string_put(game->mlx, game->win,
			(t_mlx_string){(t_mlx_point){W / 2 - 100, 50}, 0xFF0000, "COLLECT ALL EVIDENCE"});
	}
}

void	raycasting(t_game *game)
{
	int		x;
	t_ray	ray;

	if (game->showing_splash)
	{
		mlx_put_image_to_window(game->mlx, game->win,
			(t_mlx_img_data){game->splash.img, (t_mlx_point){0, 0}});
		mlx_string_put(game->mlx, game->win,
			(t_mlx_string){(t_mlx_point){W / 2 - 120, H - 50}, 0xFFFFFF,
			"PRESS ANY KEY TO START"});
		return ;
	}
	x = 0;
	while (x < W)
	{
		calculate_ray_vars(game, x, &ray);
		calculate_step_dist(game, &ray);
		perform_dda(game, &ray);
		if (ray.side == 0)
			ray.perp_wall_dist = (ray.side_dist_x - ray.delta_dist_x);
		else
			ray.perp_wall_dist = (ray.side_dist_y - ray.delta_dist_y);
		draw_column(game, &ray, x);
		game->zbuf[x] = ray.perp_wall_dist;
		x++;
	}
	render_sprites(game);
	draw_minimap(game);
	mlx_put_image_to_window(game->mlx, game->win,
		(t_mlx_img_data){game->img.img, (t_mlx_point){0, 0}});
	check_mission_complete(game);
}
