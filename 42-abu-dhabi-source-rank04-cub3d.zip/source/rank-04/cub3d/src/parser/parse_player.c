/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_player.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/11 15:06:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/11 15:06:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"

int	is_player(char c)
{
	return (c == 'N' || c == 'S' || c == 'E' || c == 'W');
}

int	players_count(char *line)
{
	int	count_player;
	int	i;

	count_player = 0;
	i = 0;
	while (line && line[i])
	{
		if (is_player(line[i]))
			count_player++;
		i++;
	}
	return (count_player);
}

void	get_player(char **map, t_player *player)
{
	int	y;
	int	x;

	y = 0;
	while (map && map[y])
	{
		x = 0;
		while (map[y][x])
		{
			if (is_player(map[y][x]))
			{
				player->x = x;
				player->y = y;
				player->dir = map[y][x];
				player->found = 1;
				map[y][x] = '0';
				return ;
			}
			x++;
		}
		y++;
	}
}
