/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   validate_utils.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/23 15:35:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/23 15:35:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"

int	is_start_pos(char c)
{
	return (c == 'N' || c == 'S' || c == 'W' || c == 'E');
}

char	**create_visited_map(char **map, int rows)
{
	char	**visited;
	int		i;
	int		len;

	visited = malloc(sizeof(char *) * rows);
	if (!visited)
		return (NULL);
	i = 0;
	while (i < rows)
	{
		len = ft_strlen(map[i]);
		visited[i] = malloc(len);
		if (!visited[i])
			return (NULL);
		ft_memset(visited[i], 0, len);
		i++;
	}
	return (visited);
}

void	free_visited(char **visited, int rows)
{
	int	i;

	i = 0;
	while (i < rows)
	{
		free(visited[i]);
		i++;
	}
	free(visited);
}

int	push(t_point *stack, int *top, t_point p, int max)
{
	if (*top >= max)
		return (0);
	stack[(*top)++] = p;
	return (1);
}
