/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   entities.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/17 18:20:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/17 18:20:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"

static int	count_sprites(char **map)
{
	int	y;
	int	x;
	int	c;

	c = 0;
	y = 0;
	while (map && map[y])
	{
		x = 0;
		while (map[y][x])
		{
			if (map[y][x] == '2')
				c++;
			x++;
		}
		y++;
	}
	return (c);
}

static void	assign_entities(t_game *game)
{
	int	y;
	int	x;
	int	idx;

	idx = 0;
	y = 0;
	while (game->map && game->map[y])
	{
		x = 0;
		while (game->map[y][x])
		{
			if (game->map[y][x] == '2')
			{
				game->sprites[idx].x = x + 0.5;
				game->sprites[idx].y = y + 0.5;
				game->sprites[idx].dist = 0.0;
				idx++;
			}
			x++;
		}
		y++;
	}
}

void	collect_entities(t_game *game)
{
	game->sprite_count = count_sprites(game->map);
	game->sprites = NULL;
	if (game->sprite_count > 0)
	{
		game->sprites = (t_sprite *)malloc(sizeof(t_sprite)
				* game->sprite_count);
		if (!game->sprites)
			error_exit("Malloc failed");
	}
	assign_entities(game);
}
