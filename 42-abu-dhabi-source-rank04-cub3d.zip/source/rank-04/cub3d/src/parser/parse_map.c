/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_map.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/11 15:07:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/11 15:07:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"
#include "../../utils/get_next_line/get_next_line.h"

int	map_count_line(char *file)
{
	int		fd;
	char	*line;
	int		in_map;
	int		count;

	in_map = 0;
	count = 0;
	fd = open(file, O_RDONLY);
	if (fd < 0)
		return (0);
	line = get_next_line(fd);
	while (line != NULL)
	{
		if (!in_map && is_map_line(line))
			in_map = 1;
		if (in_map && !is_empty_line(line))
			count++;
		free(line);
		line = get_next_line(fd);
	}
	close(fd);
	return (count);
}
