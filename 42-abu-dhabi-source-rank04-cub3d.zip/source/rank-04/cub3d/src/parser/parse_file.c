/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_file.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/11 15:09:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/11 15:09:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"
#include "../../utils/get_next_line/get_next_line.h"

static void	handle_map_line(t_game *game, char *line, int *i, int *players)
{
	game->map[(*i)++] = ft_strdup(line);
	*players += players_count(line);
	free(line);
}

static void	parse_line(t_game *game, char *line, int *in_map)
{
	if (!(*in_map))
	{
		parse_texture_line(game, line);
		parse_color_line(game, line);
		free(line);
	}
	else
	{
		free(line);
		error_exit("Invalid line inside map");
	}
}

static void	process_gnl_line(t_game *game, char *line, int *in_map, int *p)
{
	if (is_empty_line(line))
	{
		if (*in_map)
			error_exit("Empty line inside map");
		free(line);
	}
	else if (is_map_line(line))
	{
		*in_map = 1;
		handle_map_line(game, line, &p[0], &p[1]);
	}
	else
		parse_line(game, line, in_map);
}

static void	read_map_and_config(t_game *game, int fd)
{
	char	*line;
	int		in_map;
	int		p[2];

	in_map = 0;
	p[0] = 0;
	p[1] = 0;
	line = get_next_line(fd);
	while (line != NULL)
	{
		process_gnl_line(game, line, &in_map, p);
		line = get_next_line(fd);
	}
	game->map[p[0]] = NULL;
	if (p[1] != 1)
		error_exit("Invalid number of players");
}

void	parse_file(t_game *game, char *file)
{
	int	fd;
	int	map_size;
	int	rows;

	rows = 0;
	fd = open(file, O_RDONLY);
	if (fd < 0)
		error_exit("Cannot open file");
	map_size = map_count_line(file);
	if (map_size == 0)
		error_exit("Map not found");
	game->map = malloc(sizeof(char *) * (map_size + 1));
	if (!game->map)
		error_exit("Malloc failed");
	read_map_and_config(game, fd);
	close(fd);
	while (game->map[rows])
		rows++;
	if (!validate_map(game->map, rows))
		error_exit("Invalid map");
}
