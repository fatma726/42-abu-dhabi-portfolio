/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_resolution.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/20 07:30:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/20 07:30:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"

static int	is_valid_resolution_str(char *str)
{
	int	i;

	i = 0;
	if (!str || !str[0])
		return (0);
	if (str[0] == '-')
		return (-1);
	while (str[i] && str[i] != '\n')
	{
		if (str[i] < '0' || str[i] > '9')
			return (0);
		i++;
	}
	return (1);
}

static void	check_valid_res(t_game *game, char *s)
{
	int	valid;

	valid = is_valid_resolution_str(s);
	if (valid == -1)
		error_exit(game, "Invalid resolution: negative value");
	if (valid == 0)
		error_exit(game, "Invalid resolution: non-numeric value");
}

static void	clamp_resolution(t_game *game)
{
	if (game->width > 2560)
		game->width = 2560;
	if (game->height > 1440)
		game->height = 1440;
	if (game->width < 100)
		game->width = 100;
	if (game->height < 100)
		game->height = 100;
}

void	parse_resolution_line(t_game *game, char *line)
{
	char	**split;

	if (ft_strncmp(line, "R ", 2))
		return ;
	if (game->parsed & 128)
		error_exit(game, "Duplicate resolution");
	split = ft_split(line + 2, ' ');
	if (!split || !split[0] || !split[1])
		error_exit(game, "Invalid resolution format");
	check_valid_res(game, split[0]);
	check_valid_res(game, split[1]);
	game->width = ft_atoi(split[0]);
	game->height = ft_atoi(split[1]);
	if (!game->save_bmp)
		clamp_resolution(game);
	game->parsed |= 128;
	free_split(split);
}
