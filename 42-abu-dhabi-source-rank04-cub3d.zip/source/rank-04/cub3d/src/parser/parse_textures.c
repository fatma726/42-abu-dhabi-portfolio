/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_textures.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/11 15:08:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/11 15:08:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"

void	parse_texture_line(t_game *game, char *line)
{
	if (!ft_strncmp(line, "NO ", 3))
		game->tex_path.north = trim_newline(ft_strdup(line + 3));
	else if (!ft_strncmp(line, "SO ", 3))
		game->tex_path.south = trim_newline(ft_strdup(line + 3));
	else if (!ft_strncmp(line, "WE ", 3))
		game->tex_path.west = trim_newline(ft_strdup(line + 3));
	else if (!ft_strncmp(line, "EA ", 3))
		game->tex_path.east = trim_newline(ft_strdup(line + 3));
}
