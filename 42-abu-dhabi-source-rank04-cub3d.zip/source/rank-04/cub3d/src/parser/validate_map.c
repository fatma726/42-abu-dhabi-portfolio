/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   validate_map.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/11 15:10:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/11 15:10:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"

int	is_valid_walkable(char c)
{
	return (c == '0' || c == '2' || c == 'N' || c == 'S' || c == 'E'
		|| c == 'W');
}

int	check_neighbors(char **map, int x, int y, int rows)
{
	int	row_len;
	int	prev_row_len;
	int	next_row_len;

	row_len = ft_strlen(map[y]);
	if (x - 1 < 0 || map[y][x - 1] == ' ' || map[y][x - 1] == '\n')
		return (0);
	if (x + 1 >= row_len || map[y][x + 1] == ' ' || map[y][x + 1] == '\n')
		return (0);
	if (y - 1 < 0)
		return (0);
	prev_row_len = ft_strlen(map[y - 1]);
	if (x >= prev_row_len || map[y - 1][x] == ' ' || map[y - 1][x] == '\n')
		return (0);
	if (y + 1 >= rows)
		return (0);
	next_row_len = ft_strlen(map[y + 1]);
	if (x >= next_row_len || map[y + 1][x] == ' ' || map[y + 1][x] == '\n')
		return (0);
	return (1);
}

int	validate_map(char **map, int rows)
{
	int	x;
	int	y;

	y = 0;
	while (y < rows)
	{
		x = 0;
		while (map[y][x])
		{
			if (is_valid_walkable(map[y][x]))
			{
				if (!check_neighbors(map, x, y, rows))
					return (0);
			}
			x++;
		}
		y++;
	}
	return (1);
}
