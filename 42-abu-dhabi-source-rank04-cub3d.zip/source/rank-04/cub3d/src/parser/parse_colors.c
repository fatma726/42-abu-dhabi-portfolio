/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_colors.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/11 15:05:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/11 15:05:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"

static int	rgb_to_int(int r, int g, int b)
{
	return ((r << 16) | (g << 8) | b);
}

static void	set_color(t_game *game, char type, int *rgb)
{
	if (type == 'F')
	{
		game->floor.r = rgb[0];
		game->floor.g = rgb[1];
		game->floor.b = rgb[2];
		game->floor.value = rgb_to_int(rgb[0], rgb[1], rgb[2]);
	}
	else if (type == 'C')
	{
		game->ceiling.r = rgb[0];
		game->ceiling.g = rgb[1];
		game->ceiling.b = rgb[2];
		game->ceiling.value = rgb_to_int(rgb[0], rgb[1], rgb[2]);
	}
}

void	parse_color_line(t_game *game, char *line)
{
	char	**split;
	int		rgb[3];
	int		i;

	if (line[0] != 'F' && line[0] != 'C')
		return ;
	split = ft_split(line + 1, ',');
	if (!split || !split[0] || !split[1] || !split[2] || split[3])
		error_exit("Invalid color format");
	i = 0;
	while (i < 3)
	{
		rgb[i] = ft_atoi(split[i]);
		if (rgb[i] < 0 || rgb[i] > 255)
			error_exit("Invalid color range");
		i++;
	}
	set_color(game, line[0], rgb);
	free_split(split);
}
