/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/11 15:11:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/11 15:11:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minilibx/mlx.h"
#include "../utils/get_next_line/get_next_line.h"
#include "../includes/cub3d.h"

static void	validate_args(int ac, char **av)
{
	if (ac != 2)
		error_exit("Wrong number of arguments");
	if (!has_cub_extension(av[1]))
		error_exit("File must have .cub extension");
}

int	exit_game(t_game *game)
{
	(void)game;
	exit(0);
	return (0);
}

int	main(int ac, char **av)
{
	t_game	game;

	validate_args(ac, av);
	parse_file(&game, av[1]);
	setup_player(&game);
	collect_entities(&game);
	if (game.floor.value == 0 || game.ceiling.value == 0)
		error_exit("Invalid floor or ceiling color");
	init_game(&game);
	init_keys(&game);
	raycasting(&game);
	mlx_hook(game.win, (t_mlx_hook){2, 1L << 0, handle_keypress, &game});
	mlx_hook(game.win, (t_mlx_hook){3, 1L << 1, handle_keyrelease, &game});
	mlx_hook(game.win, (t_mlx_hook){17, 0, exit_game, &game});
	mlx_loop_hook(game.mlx, game_loop, &game);
	mlx_loop(game.mlx);
	return (0);
}
