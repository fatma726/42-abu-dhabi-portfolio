/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cub3d.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <marvin@42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/11 16:30:00 by fatmtahm          #+#    #+#             */
/*   Updated: 2026/01/11 16:30:00 by fatmtahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CUB3D_H
# define CUB3D_H

# include <stdlib.h>
# include <unistd.h>
# include <fcntl.h>
# include <stdio.h>

# define W 1280
# define H 720
# define TEX_N 0
# define TEX_S 1
# define TEX_W 2
# define TEX_E 3
# define SPRITE_FRAMES 2

typedef struct s_tex_path
{
	char	*north;
	char	*south;
	char	*west;
	char	*east;
}	t_tex_path;

typedef struct s_color
{
	int	r;
	int	g;
	int	b;
	int	value;
}	t_color;

typedef struct s_img
{
	void	*img;
	char	*addr;
	int		bpp;
	int		line_len;
	int		endian;
	int		width;
	int		height;
}	t_img;

typedef struct s_player
{
	int		x;
	int		y;
	char	dir;
	int		found;
	double	pos_x;
	double	pos_y;
	double	dir_x;
	double	dir_y;
	double	plane_x;
	double	plane_y;
}	t_player;

typedef struct s_sprite
{
	double	x;
	double	y;
	double	dist;
	int		collected;
}	t_sprite;

typedef struct s_keys
{
	int	w;
	int	s;
	int	a;
	int	d;
	int	left;
	int	right;
}	t_keys;

typedef struct s_ray
{
	double	dir_x;
	double	dir_y;
	int		map_x;
	int		map_y;
	double	side_dist_x;
	double	side_dist_y;
	double	delta_dist_x;
	double	delta_dist_y;
	double	perp_wall_dist;
	int		step_x;
	int		step_y;
	int		side;
	int		line_height;
	int		draw_start;
	int		draw_end;
	int		color;
}	t_ray;

typedef struct s_game
{
	void		*mlx;
	void		*win;
	t_img		img;
	t_img		textures[4];
	t_player	player;
	char		**map;
	t_tex_path	tex_path;
	t_color		floor;
	t_color		ceiling;
	t_keys		keys;
	t_img		sprite_tex[SPRITE_FRAMES];
	t_sprite	*sprites;
	int			sprite_count;
	double		zbuf[W];
	int			anim_frame;
	int			showing_splash;
	t_img		splash;
}	t_game;

/* game */
int		is_wall(t_game *game, double x, double y);
int		handle_keypress(int keycode, void *param);
int		handle_keyrelease(int keycode, void *param);
int		game_loop(void *param);
void	init_game(t_game *game);
void	move_forward_backward(t_game *game, double speed, int keycode);
void	rotate_player(t_game *game, double rot_speed, int keycode);
void	move_strafe(t_game *game, double speed, int keycode);
void	init_player_dir(t_player *p);
void	init_keys(t_game *game);

/* parser */
void	parse_color_line(t_game *game, char *line);
int		has_cub_extension(char *file);
void	load_texture(t_game *game, t_img *tex, char *path);
void	load_png_texture(t_game *game, t_img *tex, char *path);
int		is_empty_line(char *line);
int		is_map_line(char *line);
int		map_count_line(char *file);
int		is_player(char c);
int		players_count(char *line);
void	get_player(char **map, t_player *player);
void	parse_texture_line(t_game *game, char *line);
int		is_valid_walkable(char c);
int		check_neighbors(char **map, int x, int y, int rows);
int		validate_map(char **map, int rows);
void	parse_file(t_game *game, char *file);
void	parse_content(t_game *game, int fd, char *file);
void	setup_player(t_game *game);
void	collect_entities(t_game *game);

/* render */
void	calculate_ray_vars(t_game *game, int x, t_ray *ray);
void	calculate_step_dist(t_game *game, t_ray *ray);
void	perform_dda(t_game *game, t_ray *ray);
void	raycasting(t_game *game);
int		get_texture_color(t_img *tex, int x, int y);
void	put_pixel(t_img *img, int x, int y, int color);
void	draw_minimap(t_game *game);
void	render_sprites(t_game *game);
void	draw_column(t_game *game, t_ray *ray, int x);

/* utils */
void	free_split(char **split);
void	free_map(char **map);
void	error_exit(char *str);
int		ft_atoi(const char *str);
char	**ft_split(char const *s, char c);
size_t	ft_strlen(const char *str);
char	*ft_strdup(char *s);
int		ft_strncmp(const char *s1, const char *s2, size_t n);
char	*trim_newline(char *s);

#endif
