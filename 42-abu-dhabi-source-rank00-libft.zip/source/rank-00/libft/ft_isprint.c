/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isprint.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: faahmed <faahmed@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/28 11:25:44 by faahmed           #+#    #+#             */
/*   Updated: 2024/12/28 15:51:41 by faahmed          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_isprint(int c)
{
	if (c >= 32 && c <= 126)
		return (1);
	return (0);
}
#include <stdio.h>
#include "libft.h"

int main(void)
{
    char test1 = 'A';
    char test2 = ' ';
    char test3 = '\t';

    printf("Is '%c' printable? %d\n", test1, ft_isprint(test1)); // Should return 1
    printf("Is '%c' printable? %d\n", test2, ft_isprint(test2)); // Should return 1
    printf("Is '\\t' printable? %d\n", ft_isprint(test3));       // Should return 0

    return 0;
}