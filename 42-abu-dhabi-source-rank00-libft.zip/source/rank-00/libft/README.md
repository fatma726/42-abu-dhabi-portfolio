# Rank 00 · Libft

Fatma's reusable C library: libc-style string, memory, conversion, and file-descriptor helpers packaged as `libft.a`.

```bash
make
make clean
make fclean
```

The public API is declared in `libft.h`. Start with small pure functions, test empty strings and allocation failures, then link another program with `-L. -lft`. See the [animated lesson](../../../lessons/index.html#libft) for the memory model, build flow, tests, and common mistakes.
