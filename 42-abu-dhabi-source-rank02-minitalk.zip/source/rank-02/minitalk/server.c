/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   server.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <fatmtahmdabrahym@stud    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/01 12:00:00 by fabdullah         #+#    #+#             */
/*   Updated: 2025/05/17 19:54:04 by fatmtahmdab      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk.h"

t_message	g_msg = {0, 0, 0};

static void	process_char(void)
{
	if (g_msg.c == '\0')
	{
		ft_putchar('\n');
		if (g_msg.client_pid)
			kill(g_msg.client_pid, SIGUSR2);
	}
	else
	{
		ft_putchar(g_msg.c);
		if (g_msg.client_pid)
			kill(g_msg.client_pid, SIGUSR1);
	}
	g_msg.c = 0;
	g_msg.bit = 0;
}

void	handle_signal(int sig, siginfo_t *info, void *context)
{
	(void)context;
	if (info->si_pid)
		g_msg.client_pid = info->si_pid;
	if (sig == SIGUSR1)
		g_msg.c |= (0x80 >> g_msg.bit);
	g_msg.bit++;
	if (g_msg.bit == CHAR_BIT)
		process_char();
	else if (g_msg.client_pid)
		kill(g_msg.client_pid, SIGUSR1);
}

int	main(void)
{
	struct sigaction	sa;

	ft_putstr("Server PID: ");
	ft_putnbr(getpid());
	ft_putchar('\n');
	sa.sa_sigaction = handle_signal;
	sa.sa_flags = SA_SIGINFO | SA_RESTART;
	sigemptyset(&sa.sa_mask);
	sigaddset(&sa.sa_mask, SIGUSR1);
	sigaddset(&sa.sa_mask, SIGUSR2);
	if (sigaction(SIGUSR1, &sa, NULL) == -1)
		exit(1);
	if (sigaction(SIGUSR2, &sa, NULL) == -1)
		exit(1);
	while (1)
		pause();
	return (0);
}
