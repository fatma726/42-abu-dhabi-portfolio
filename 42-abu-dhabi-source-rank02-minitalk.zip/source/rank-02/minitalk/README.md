# Rank 02 · Minitalk

An inter-process message channel built with `SIGUSR1` and `SIGUSR2`. The client encodes each byte as bits; the server rebuilds bytes and acknowledges progress.

```bash
make
./server
./client <server-pid> "hello 42"
```

Try empty messages, long messages, invalid PIDs, and the bonus acknowledgement path. See the [animated lesson](../../../lessons/index.html#minitalk) for the signal protocol and bit-by-bit flow.
