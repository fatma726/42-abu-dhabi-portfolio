/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   client.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <fatmtahmdabrahym@stud    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/01 12:00:00 by fabdullah         #+#    #+#             */
/*   Updated: 2025/05/17 19:34:16 by fatmtahmdab      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk.h"

volatile sig_atomic_t	g_ack = 0;

void	handle_client_signal(int sig)
{
	if (sig == SIGUSR1)
		g_ack = 1;
	else if (sig == SIGUSR2)
	{
		ft_putstr("Message received successfully!\n");
		exit(0);
	}
}

static void	check_response(void)
{
	int	timeout;

	timeout = 0;
	while (!g_ack && timeout < 100000)
	{
		usleep(10);
		timeout++;
	}
	if (!g_ack)
		exit(1);
}

void	send_char(char c, pid_t server_pid)
{
	int	bit;

	bit = 0;
	while (bit < CHAR_BIT)
	{
		g_ack = 0;
		if (c & (0x80 >> bit))
		{
			if (kill(server_pid, SIGUSR1) == -1)
				exit(1);
		}
		else
		{
			if (kill(server_pid, SIGUSR2) == -1)
				exit(1);
		}
		check_response();
		bit++;
	}
}

int	main(int argc, char **argv)
{
	pid_t	server_pid;
	int		i;

	if (argc != 3)
	{
		ft_putstr("Usage: ./client <server_pid> \"message\"\n");
		return (1);
	}
	server_pid = ft_atoi(argv[1]);
	if (server_pid <= 0)
	{
		ft_putstr("Invalid PID\n");
		return (1);
	}
	signal(SIGUSR1, handle_client_signal);
	signal(SIGUSR2, handle_client_signal);
	i = 0;
	while (argv[2][i])
	{
		send_char(argv[2][i], server_pid);
		i++;
	}
	send_char('\0', server_pid);
	return (0);
}
