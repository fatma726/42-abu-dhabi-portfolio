/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   input.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <fatmtahmdabrahym@stud    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 1970/01/01 00:00:00 by fatima            #+#    #+#             */
/*   Updated: 2025/10/06 21:32:07 by fatmtahmdab      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include <errno.h>
#include <poll.h>

/*
 * In some environments (e.g., when launched from a bash script that itself is
 * reading from stdin), bash may set close-on-exec on its script fd, causing our
 * fd 0 to be closed (or immediately EOF) in the child. To behave robustly in
 * non‑TTY mode, we try to discover an alternative readable FD that contains the
 * script stream (bash often uses high-numbered FDs like 255). This fallback is
 * only used when stdin is not a TTY and the first read fails/EOFs.
 */

static FILE	*g_fallback_file = NULL;

static FILE	*try_open_fd_as_file(int fd)
{
    int         flags;
    int         dupfd;
    FILE        *fp;
    struct pollfd pfd;

    if (fd <= 2)
        return (NULL);
    flags = fcntl(fd, F_GETFD);
    if (flags == -1)
        return (NULL);
    /* Only consider FDs that appear readable right now to avoid blocking */
    pfd.fd = fd;
    pfd.events = POLLIN;
    pfd.revents = 0;
    if (poll(&pfd, 1, 0) <= 0 || !(pfd.revents & POLLIN))
        return (NULL);
    dupfd = dup(fd);
    if (dupfd < 0)
        return (NULL);
    fp = fdopen(dupfd, "r");
    if (!fp)
    {
        close(dupfd);
        return (NULL);
    }
    return (fp);
}

static FILE	*discover_script_stream(void)
{
    FILE    *fp;
    int     fd;

    /* Prefer commonly used bash FDs first */
    fp = try_open_fd_as_file(255);
    if (fp)
        return (fp);
    fp = try_open_fd_as_file(10);
    if (fp)
        return (fp);
    /* Scan a small range of FDs to find a readable FIFO/regular file */
    for (fd = 3; fd < 255; ++fd)
    {
        if (fd == 10)
            continue;
        fp = try_open_fd_as_file(fd);
        if (fp)
            return (fp);
    }
    return (NULL);
}

static void	mark_nontext(const char *buf, size_t nread)
{
	size_t			i;
	unsigned char	c;

	i = 0;
	while (i < nread)
	{
		c = (unsigned char)buf[i];
		if (c != '\n' && ((c < 32 && c != '\t') || c >= 128))
		{
			set_nontext_input(true);
			break ;
		}
		i++;
	}
}

char	*read_line_non_tty(void)
{
    char		*buf;
    size_t		cap;
    ssize_t		nread;

    /* First, try the canonical stdin stream */
    buf = NULL;
    cap = 0;
    errno = 0;
    nread = getline(&buf, &cap, stdin);
    if (nread >= 0)
    {
        mark_nontext(buf, (size_t)nread);
        if (nread > 0 && buf[nread - 1] == '\n')
            buf[nread - 1] = '\0';
        return (buf);
    }
    /* If stdin failed/EOF immediately, attempt fallback discovery once */
    if (buf)
        free(buf);
    if (!g_fallback_file)
        g_fallback_file = discover_script_stream();
    if (!g_fallback_file)
        return (NULL);
    buf = NULL;
    cap = 0;
    errno = 0;
    nread = getline(&buf, &cap, g_fallback_file);
    if (nread < 0)
    {
        if (buf)
            free(buf);
        return (NULL);
    }
    mark_nontext(buf, (size_t)nread);
    if (nread > 0 && buf[nread - 1] == '\n')
        buf[nread - 1] = '\0';
    return (buf);
}

void	handle_eof_exit(char **envp, t_node *node)
{
	if (node)
	{
		if (node->pwd)
			free(node->pwd);
		if (node->path_fallback)
			free(node->path_fallback);
	}
	if (envp)
		strarrfree(envp);
	clear_history();
	restore_termios();
	(void)node;
	exit(get_exit_status());
}

int	process_read_line(char **result, char **cur_prompt, char *orig)
{
	char	*line;

	line = readline(*cur_prompt);
	if (!line)
	{
		if (*result)
			free(*result);
		return (-1);
	}
	if (!append_line(result, line))
		return (-1);
	if (quote_check(*result, (int)ft_strlen(*result), NULL) == 0)
		return (0);
	if (*cur_prompt != orig)
		free(*cur_prompt);
	*cur_prompt = ft_strdup("> ");
	return (1);
}

char	*get_line(char *str)
{
    char	*line;
    char	*prompt;

    if (!isatty(STDIN_FILENO))
    {
        if (str)
            ft_putendl_fd(str, STDOUT_FILENO);
        return (read_line_non_tty());
    }
	prompt = ft_strdup(str);
	line = get_continuation_line(prompt);
	free(prompt);
	return (line);
}
