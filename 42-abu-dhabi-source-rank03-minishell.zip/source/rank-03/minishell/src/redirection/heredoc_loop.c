/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   heredoc_loop.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fatmtahmdabrahym <fatmtahmdabrahym@stud    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 1970/01/01 00:00:00 by fatima            #+#    #+#             */
/*   Updated: 2025/10/18 21:27:15 by fatmtahmdab      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

char	*get_heredoc_line(void);
int		check_heredoc_signal(void);

/* context struct is declared in minishell.h */

static void	write_heredoc_line(bool expand_vars, char *line,
				char **envp, t_node *node)
{
	char	*expanded_line;

	if (node->redir_fd < 0)
		return ;
	if (expand_vars)
	{
		expanded_line = expand_envvar(line, envp, node);
		ft_putendl_fd(expanded_line, node->redir_fd);
		free(expanded_line);
	}
	else
	{
		ft_putendl_fd(line, node->redir_fd);
		free(line);
	}
}

static void	maybe_exit_on_exit_token(struct s_hdctx *c, char *line)
{
	if (!c->has_command && ft_strlen(line) == 4
		&& ft_strncmp(line, "exit", 5) == 0)
	{
		free(line);
		unlink(".temp");
		cleanup_and_exit(c->args, c->envp, c->node);
	}
}

static int	process_heredoc_iteration(struct s_hdctx *c)
{
	char	*line;

	if (check_heredoc_signal())
		return (1);
	line = get_heredoc_line();
	if (!line)
	{
		if (check_heredoc_signal())
			return (1);
		return (2);
	}
	maybe_exit_on_exit_token(c, line);
	if (ft_strncmp(line, c->delimiter, ft_strlen(c->delimiter)) == 0
		&& ft_strlen(line) == ft_strlen(c->delimiter))
	{
		free(line);
		return (0);
	}
	write_heredoc_line(c->expand_vars, line, c->envp, c->node);
	return (1);
}

static int	process_heredoc_loop(struct s_hdctx *c)
{
	int	result;

	c->lines_read = 0;
	while (1)
	{
		result = process_heredoc_iteration(c);
		if (result == 0)
			return (0);
		if (result == 1)
		{
			c->lines_read++;
			continue ;
		}
		if (result == 2)
			break ;
	}
	if (c->lines_read > 0)
		c->node->heredoc_swallowed_input = true;
	return (2);
}

int	heredoc_loop(char **args, char **envp, int *i, t_node *node)
{
	char			*delimiter;
	char			*clean_delimiter;
	int				unterminated;
	struct s_hdctx	c;

	delimiter = args[*i + 1];
	if (delimiter && delimiter[0] == (char)31)
		clean_delimiter = delimiter + 1;
	else
		clean_delimiter = delimiter;
	c.args = args;
	c.envp = envp;
	c.node = node;
	c.has_command = command_has_non_redir_token(args);
	c.delimiter = clean_delimiter;
	c.expand_vars = (!ft_strchr(clean_delimiter, '"')
			&& !ft_strchr(clean_delimiter, '\''));
	unterminated = process_heredoc_loop(&c);
	if (unterminated)
		node->heredoc_unterminated = true;
	return (unterminated);
}
