# Rank 03 · Minishell

Fatma's parser/executor snapshot for a Bash-style shell: quoting, expansion, pipelines, redirections, heredocs, built-ins, signals, processes, and cleanup.

On macOS, install Readline and adjust the Makefile's include/library paths if needed:

```bash
make
./minishell
make bonus
./minishell_bonus
```

Exercise one feature at a time (`echo`, `$VAR`, pipes, `>`, `<`, `>>`, `<<`, signals), then compare behavior with Bash. See the [animated lesson](../../../lessons/index.html#minishell) for the token-to-process flow and debugging checklist.
